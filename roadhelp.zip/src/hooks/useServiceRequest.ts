import { useState, useCallback } from 'react';
import { ServiceRequest, RequestStatus, RequestProposal } from '@/types';
import { useAuth } from './useAuth';

export function useServiceRequest() {
  const [isLoading, setIsLoading] = useState(false);
  const { profile } = useAuth();

  const createRequest = useCallback(async (data: Omit<ServiceRequest, 'id' | 'createdAt' | 'isPaid' | 'status'>) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create request');
      const result = await response.json();
      return result.data.id;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const submitProposal = useCallback(async (requestId: string, proposal: Omit<RequestProposal, 'id' | 'createdAt' | 'requestId'>) => {
    if (!profile) throw new Error('Not authenticated');
    setIsLoading(true);
    try {
      const fullProposal = {
        ...proposal,
        providerId: profile.uid,
        providerName: profile.fullName,
        providerPhone: profile.phone,
        providerRating: profile.rating || 5,
        providerVehicleNumber: profile.vehicleNumber || '',
      };
      
      const response = await fetch(`/api/requests/${requestId}/proposals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fullProposal),
      });
      if (!response.ok) throw new Error('Failed to submit proposal');
      const result = await response.json();
      return result.data.id;
    } finally {
      setIsLoading(false);
    }
  }, [profile]);

  const selectProposal = useCallback(async (requestId: string, proposal: RequestProposal) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/proposals/select`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proposal }),
      });
      if (!response.ok) throw new Error('Failed to select proposal');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateRequestStatus = useCallback(async (requestId: string, status: RequestStatus, extras?: Partial<ServiceRequest>) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, extras }),
      });
      if (!response.ok) throw new Error('Failed to update status');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const acceptRequest = useCallback(async (requestId: string) => {
    if (!profile) throw new Error('Not authenticated');
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/accept`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile }),
      });
      if (!response.ok) throw new Error('Failed to accept request');
    } finally {
      setIsLoading(false);
    }
  }, [profile]);

  const completeRequest = useCallback(async (requestId: string, finalPrice: number, additionalFees = 0) => {
    if (!profile) throw new Error('Not authenticated');
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/complete`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ finalPrice, additionalFees }),
      });
      if (!response.ok) throw new Error('Failed to complete request');
    } finally {
      setIsLoading(false);
    }
  }, [profile]);

  const processPayment = useCallback(async (requestId: string, tip: number = 0) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/payment`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tip }),
      });
      if (!response.ok) throw new Error('Failed to process payment');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const submitRating = useCallback(async (requestId: string, rating: number, review: string, _providerId?: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/requests/${requestId}/rating`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating, review }),
      });
      if (!response.ok) throw new Error('Failed to submit rating');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const getCustomerRequests = useCallback(async (customerId: string): Promise<ServiceRequest[]> => {
    const response = await fetch(`/api/requests/customer/${customerId}`);
    if (!response.ok) throw new Error('Failed to fetch requests');
    const result = await response.json();
    return result.data;
  }, []);

  const getProviderRequests = useCallback(async (providerId: string): Promise<ServiceRequest[]> => {
    const response = await fetch(`/api/requests/provider/${providerId}`);
    if (!response.ok) throw new Error('Failed to fetch requests');
    const result = await response.json();
    return result.data;
  }, []);

  const getPendingRequests = useCallback(async (): Promise<ServiceRequest[]> => {
    const response = await fetch(`/api/requests/pending`);
    if (!response.ok) throw new Error('Failed to fetch pending requests');
    const result = await response.json();
    return result.data;
  }, []);

  const getRequestById = useCallback(async (requestId: string): Promise<ServiceRequest | null> => {
    const response = await fetch(`/api/requests/${requestId}`);
    if (!response.ok) return null;
    const result = await response.json();
    return result.data;
  }, []);

  return {
    isLoading,
    createRequest,
    submitProposal,
    selectProposal,
    updateRequestStatus,
    acceptRequest,
    completeRequest,
    processPayment,
    submitRating,
    getCustomerRequests,
    getProviderRequests,
    getPendingRequests,
    getRequestById,
  };
}
